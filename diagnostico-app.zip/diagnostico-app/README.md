# Diagnóstico de Perfil Instagram — Mayara Arruda

## Como fazer o deploy no Replit

### 1. No Replit, crie um novo projeto Python
- Clique em "+ Create Repl"
- Escolha "Python"
- Nome: "diagnostico-instagram"

### 2. Faça upload dos arquivos
- server.py → raiz do projeto
- requirements.txt → raiz do projeto
- static/index.html → pasta "static"

### 3. Configure as variáveis de ambiente (Secrets)
No Replit, vá em "Secrets" e adicione:
- ANTHROPIC_API_KEY = sua chave da Anthropic (sk-ant-...)

### 4. Configure o main.py
O arquivo principal deve ser server.py

### 5. Atualize as URLs no server.py
Substitua "https://instagram-content-mapper--mayoliverarruda.replit.app"
pela URL do novo projeto

### 6. Clique em Run
O app vai rodar na porta 5000

### Credenciais de teste do Mercado Pago
Para testar pagamentos use:
- Cartão: 5031 4332 1540 6351
- CVV: 123
- Validade: 11/25
- Nome: APRO (para aprovar)

### Para ir para produção
1. No painel do Mercado Pago, vá em "Credenciais Produtivas"
2. Substitua o ACCESS_TOKEN no server.py pela chave produtiva
3. No criar-pagamento, mude "sandbox_init_point" para "init_point"
